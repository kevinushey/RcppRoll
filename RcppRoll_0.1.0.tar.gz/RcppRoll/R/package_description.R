#' RcppRoll
#' 
#' This package implements a number of 'roll'ing functions for \R
#' vectors and matrices.
#' 
#' @name RcppRoll
#' @docType package
#' @useDynLib RcppRoll
NULL