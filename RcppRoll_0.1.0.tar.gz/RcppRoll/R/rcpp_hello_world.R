rcpp_hello_world <-
function () 
{
}
